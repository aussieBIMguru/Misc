-- README FOR NONICA TOOLBAR BY AUSSIE BIM GURU --


-- AUTHOR --
Made by Gavin Crump (Aussie BIM Guru, t/as BIM Guru)


-- TERMS OF USE --
Free for use and modification but not for resale purposes.

No responsibility taken for the result of using these packages/scripts.
Use with due care at your own discretion/caution.


-- INSTALL STEPS --

1. Install Nonica Pro for Dynamo/Revit
2. Copy the 'Aussie BIM Guru' folder to C:\NONICAPRO\OtherFiles
3. Copy the resource 'logo.png' to your Documents folder
4. Open Revit and go to the Nonica tab
5. Click the far left button ('Default') and go to Settings
6. Select the 'Import' button
7. Navigate to the folder C:\NONICAPRO\OtherFiles\Aussie BIM Guru
8. Load the file 'ABG Toolbar 1-3.nonica'
9. You should now have the toolbar available!


-- VERSIONING --

Built and tested in Dynamo 2.3.0 for Revit 2020.2.3

For use with NonicaTab PRO which can be found on the App Store:
https://apps.autodesk.com/RVT/en/Detail/Index?id=9212699819557407848

Packages required to run scripts

Crumple (2021.8.4)
Rhythm (2020.9.8)
Orchid (203.3.0.7829)
Data-Shapes (2022.2.96)
Clockwork for Dynamo 2.x (2.3.0)

Packages shown in (brackets) are the ones used to test the scripts, but other versions may also work. Do not attempt to run the scripts without a stable build of these packages installed if you want ideal results.