# import libraries
from pyrevit import revit,DB,script,forms

# choose a directory
dirPath = forms.pick_folder(title = "Choose a directory")

if not dirPath:
	script.exit()

# choose a run mode
sub = "Choose carefully, large directories can take a while..."
msg = "Would you like to read sub-directories as well as the root level?"

runMode = forms.alert(msg, sub_msg = sub, title = "Choose run mode", ok=False, yes=True, no=True, warn_icon=False)

if runMode == None:
	script.exit()

# libraries for search
import clr
from System.IO import Directory, SearchOption

# make function to get files
def directory_getFamilies(dirPath, deepSearch = False):
	filePaths, fileNames = [],[]
	if Directory.Exists(dirPath):
		if deepSearch:
			mode = SearchOption.AllDirectories
		else:
			mode = SearchOption.TopDirectoryOnly
		dirPaths = Directory.GetFiles(dirPath, ".", mode)
		# Get family files only
		for fp in dirPaths:
			if ".rfa" in fp:
				if ".00" not in fp:
					filePaths.append(fp)
					# get file name
					fileName = fp.rsplit("\\",1)[-1]
					noExt    = fileName.replace(".rfa","")
					fileNames.append(noExt)
	# return the outcome
	return [filePaths, fileNames]

# Get file paths and names of family files
filePaths, fileNames = directory_getFamilies(dirPath, runMode)

if len(filePaths) == 0:
	forms.alert("No family files found in directories.", title = "Script cancelled")
	script.exit()

# get revit document, and families
doc = revit.doc

families = DB.FilteredElementCollector(doc).OfClass(DB.Family).ToElements()

# Find matches to the files in the directory
matches = []

for f in families:
	famName = f.Name
	if famName in fileNames:
		catName = f.FamilyCategory.Name
		match   = catName + ": " + famName
		matches.append(match)

if len(matches) == 0:
	forms.alert("No matching families found in directory/project.", title = "Script cancelled")
	script.exit()

matches.sort()

# Choose which to reload
reloadNames = forms.SelectFromList.show(matches, title = "Select families", button_name = "Reload", multiselect = True)

if not reloadNames:
	script.exit()

# Building inteface class, load family
class FamilyOption(DB.IFamilyLoadOptions):
	def OnFamilyFound(self, familyInUse, overwriteParameterValues):
		overwriteParameterValues = True
		return True
	def OnSharedFamilyFound(self, sharedFamily, familyInUse, source, overwriteParameterValues):
		overwriteParameterValues = False
		source = DB.FamilySource.Project
		return True

def family_reload(filePath, loadOptions, myDoc = revit.doc):
	try:
		myDoc.LoadFamily(filePath, loadOptions)
		return 1
	except:
		return 0

# Load the family files
with forms.ProgressBar(step = 1, title = "Reloading families..." + "{value} of {max_value}", cancellable = True) as pb1:
	
	# Progress bar properties
	pbTotal1 = len(reloadNames)
	pbCount1 = 1
	pbWorks1 = 0
	
	# Family load options
	loadOptions = FamilyOption()
	
	# Reload the families...
	with revit.Transaction("Reload families"):
		
		# For each family, reload
		for rn in reloadNames:
			
			# Pb isnt cancelled
			if pb1.cancelled:
				break
			else:
				famName = rn.rsplit(": ",1)[-1]
				ind     = fileNames.index(famName)
				filePath = filePaths[ind]
				pbWorks1 += family_reload(filePath, loadOptions, doc)
			
			# Update progress bar
			pb1.update_progress(pbCount1, pbTotal1)
			pbCount1 += 1

# Report the outcome
msg = str(pbWorks1) + "/" + str(pbTotal1) + " families reloaded."
forms.alert(msg, title = "Script completed", warn_icon = False)