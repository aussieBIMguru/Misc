# import libraries
import clr
import webbrowser

# Load webpage
webbrowser.open('https://www.revitapidocs.com/')