# known tools
PYREVIT_CORE_RELOAD_COMMAND_NAME = 'pyrevitcore-pyrevit-pyrevit-tools-reload'
