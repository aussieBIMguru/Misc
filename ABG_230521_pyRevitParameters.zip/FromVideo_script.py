# import libraries
from pyrevit import DB, revit, script, forms

# Get excel file
filterXcl = 'Excel workbook|*.xlsx'

path_xcl = forms.pick_file(files_filter = filterXcl, title="Choose Excel file")

if not path_xcl:
	script.exit()

# Get family files
filterRfa = 'Revit families|*.rfa'

path_rfas = forms.pick_file(files_filter = filterRfa, multi_file=True, title="Choose families")

if not path_rfas:
	script.exit()

# Import excel data
from guRoo_xclUtils import *

xcl = xclUtils([],path_xcl)
dat = xcl.xclUtils_import("Standard", 5, 0)

# Check if data found
if dat[1] == False:
	forms.alert("No worksheet called Standard was found.", title="Script cancelled")
	script.exit()

# Set up data set
target_params, target_bipgs, fam_instances, fam_formulae = [],[],[],[]

for row in dat[0][1:]:
	target_params.append(row[0])
	target_bipgs.append(row[2])
	fam_instances.append(row[3] == "Yes")
	fam_formulae.append(row[4])

# Getting all shared parameters and names
app = __revit__.Application

spFile = app.OpenSharedParameterFile()
spGroups = spFile.Groups

sp_defs, sp_names = [],[]

for g in spGroups:
	for d in g.Definitions:
		sp_defs.append(d)
		sp_names.append(d.Name)

# Get target definitions
fam_defs = []

for t in target_params:
	if t in sp_names:
		ind = sp_names.index(t)
		fam_defs.append(sp_defs[ind])

# Catch if we missed a definitions
if len(fam_defs) != len(target_params):
	forms.alert("Some definitions not found, refer to report.", title="Script cancelled")
	# What is missing
	print("MISSING PARAMETERS IN SP FILE")
	print("---")
	for t in target_params:
		if t not in sp_names:
			print(t)
	script.exit()

# Import system and enumerate
import System
from System import Enum

# Get the bipgs
bipgs = [bipg for bipg in System.Enum.GetValues(DB.BuiltInParameterGroup)]
bipg_names = [str(a) for a in bipgs]

fam_bipgs = []

for t in target_bipgs:
	if t in bipg_names:
		ind = bipg_names.index(t)
		fam_bipgs.append(bipgs[ind])

# Catch if we missed a BIPG
if len(fam_bipgs) != len(target_bipgs):
	forms.alert("Some groups not found, refer to report.", title="Script cancelled")
	# What is missing
	print("INCORRECT PARAMETER GROUPS")
	print("---")
	for t in target_bipgs:
		if t not in bipg_names:
			print(t)
	script.exit()

# Function to open a document
def famDoc_open(filePath, app):
	try:
		famDoc = app.OpenDocumentFile(filePath)
		return famDoc
	except:
		return None

# Function to close a document
def famDoc_close(famDoc, saveOpt = True):
	try:
		famDoc.Close(saveOpt)
		return 1
	except:
		return 0

# Function for adding shared parameters and formulae
from Autodesk.Revit.DB import Transaction

def famDoc_addSharedParams(famDoc, famDefs, famBipgs, famInst, famForm):
	# Make sure it is a family doc
	if famDoc.IsFamilyDocument:
		# Get family manager
		famMan = famDoc.FamilyManager
		parNames = [p.Definition.Name for p in famMan.Parameters]
		params = []
		# Make a transaction
		t = Transaction(famDoc, 'Add parameters')
		t.Start()
		# Add parameters to document
		for d,b,i,f in zip(famDefs, famBipgs, famInst, famForm):
			if d.Name not in parNames:
				p = famMan.AddParameter(d,b,i)
				params.append(p)
				# Try to set formulae
				if f != None:
					try:
						famMan.SetFormula(p,f)
					except:
						pass
			else:
				pass
		# Finish up
		t.Commit()
		# Return the parameters
		return params
	# Not a family document
	else:
		return None

# Try to add parameters to each document
with forms.ProgressBar(step=1, title="Updating families", cancellable=True) as pb:
	# Set default values
	pbCount = 1
	pbTotal = len(path_rfas)
	passCount = 0
	# Run the core process
	for filePath in path_rfas:
		# Make sure pb isnt cancelled
		if pb.cancelled:
			break
		else:
			famDoc = famDoc_open(filePath, app)
			# If it worked
			if famDoc != None:
				pars = famDoc_addSharedParams(famDoc, fam_defs, fam_bipgs, fam_instances, fam_formulae)
				if pb.cancelled or len(pars) == 0:
					famDoc_close(famDoc, False)
				else:
					famDoc_close(famDoc)
					passCount += 1
			# Update progress bar
			pb.update_progress(pbCount, pbTotal)
			pbCount += 1

# Final message to the user
form_message = str(passCount) + "/" + str(pbTotal) + " families updated."
forms.alert(form_message, title = "Script completed", warn_icon = False)