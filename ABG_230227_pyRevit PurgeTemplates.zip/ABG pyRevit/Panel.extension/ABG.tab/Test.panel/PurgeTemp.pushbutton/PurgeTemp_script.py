# import pyrevit libraries
from pyrevit import revit,DB
from pyrevit import forms,script

# class to show template by name
class TemplatePurge(forms.TemplateListItem):
	@property
	def name(self):
		return doc.GetElement(self.item).Name

# function to delete
def deleteById(id):
	try:
		doc.Delete(id)
		return 1
	except:
		return 0

# get the document
doc = revit.doc

# get all views
views_all = DB.FilteredElementCollector(doc).OfClass(DB.View).WhereElementIsNotElementType().ToElements()
vfts_all  = DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType).WhereElementIsElementType().ToElements()

# get view templates and view templates in use for views
templates_all, templates_used, templates_unused = [],[],[]

for v in views_all:
	if v.IsTemplate:
		templates_all.append(v.Id)
	else:
		vtId = v.ViewTemplateId
		if vtId not in templates_used:
			templates_used.append(vtId)

# get view templates in use for view types
for vft in vfts_all:
	vtId = vft.DefaultTemplateId
	if vtId not in templates_used:
			templates_used.append(vtId)

# get unused view templates
for vt in templates_all:
	if vt not in templates_used:
		templates_unused.append(vt)

# make sure we have a view template to purge
if len(templates_unused) == 0:
	forms.alert("No unused view templates found.", title= "Script completed", warn_icon=False)
	script.exit()

# show the templates to the user to pick from
return_options = \
	forms.SelectFromList.show(
	[TemplatePurge(vt)
	for vt in templates_unused],
	title='Select View Templates to Purge',
	width=500,
	button_name='Purge',
	multiselect=True)

# make sure we have have templates to purge, then purge them
if not return_options:
	forms.alert("No view templates selected.", title= "Script cancelled")
	script.exit()
else:
	with revit.Transaction('Purge Templates'):
		count_deleted = 0
		for vt in return_options:
			count_deleted += deleteById(vt)

# report the outcome
count_total  = len(return_options)
count_failed = count_total - count_deleted

# outcome message if all purged, none purged or some purged
if count_deleted == count_total:
	msg = str(count_deleted) + " view templates purged."
elif count_deleted == 0:
	msg = "No view templates purged."
else:
	msg = str(count_deleted) + " view templates purged. " + str(count_failed) + " view templates not purged."

# display the outcome to the user
forms.alert(msg, title= "Script completed", warn_icon=False)