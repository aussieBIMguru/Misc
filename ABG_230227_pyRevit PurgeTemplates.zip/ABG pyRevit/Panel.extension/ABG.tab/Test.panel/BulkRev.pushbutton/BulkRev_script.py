# import pyrevit libraries
from pyrevit import revit
from pyrevit import forms,script,EXEC_PARAMS

# check if we are running alternatively
my_check = not(EXEC_PARAMS.config_mode)

# function to apply revisions
def reviseSheet(sht,rev,apply=True):
	# get revisions
	revs_sheet = sht.GetAdditionalRevisionIds()
	outcome = 0
	# if applying a revision
	if apply:
		# is revision not present
		if rev.Id not in revs_sheet:
			revs_sheet.Add(rev.Id)
			sht.SetAdditionalRevisionIds(revs_sheet)
			outcome += 1
	# if removing a revision
	else:
		# is revision present
		if rev.Id in revs_sheet:
			revs_sheet.Remove(rev.Id)
			sht.SetAdditionalRevisionIds(revs_sheet)
			outcome += 1
	# return the outcome
	return outcome

# make some action words
if my_check:
	action1 = "Apply"
	action2 = "Applying"
	action3 = "applied to"
else:
	action1 = "Remove"
	action2 = "Removing"
	action3 = "removed from"

# ask the user for a revision
my_revision = forms.select_revisions(title='Select Revision', button_name = 'Select', width=300, multiple=False)

# check if we have a revision
if not my_revision:
	forms.alert("No revision selected", "Script cancelled")
	script.exit()
else:
	# ask for sheets
	my_sheets = forms.select_sheets(title='Select sheet(s)', button_name = action1, include_placeholder = False, use_selection = True)
	# do we have sheets
	if my_sheets:
		# create a tracker
		rev_set = 0
		# progress bar variables
		pb_step  = 1
		pb_len   = len(my_sheets)
		pb_count = 1
		# make a loading bar
		with forms.ProgressBar(step = pb_step, title = action2 + " revisions...") as pb:
			# open a transaction
			with revit.Transaction("Bulk revisioning"):
				for s in my_sheets:
					check = reviseSheet(s,my_revision,my_check)
					rev_set += check
					# update prorgess bar
					pb.update_progress(pb_count,pb_len)
					pb_count += 1

# primary message
if rev_set > 0:
	msg_main   = r'"' + my_revision.Name + r'" ' + action3 + " " + str(rev_set) + " sheets."
	msg_return = "\n\n"
else:
	msg_main = ""
	msg_return = ""

# secondary revision
excess = len(my_sheets) - rev_set

if excess > 0:
	msg_extra = msg_return + str(excess) + " sheets did not require changes."
else:
	msg_extra = ""

# display final message
forms.alert(msg_main + msg_extra, title = "Script completed", warn_icon=False)