# import libraries
from pyrevit import EXEC_PARAMS
from pyrevit import forms
import webbrowser

# not today
EXEC_PARAMS.event_args.Cancel = True
webbrowser.open('https://www.youtube.com/watch?v=a3Z7zEc7AXQ?autoplay=1')