# Boilerplate
from pyrevit import script, revit, DB, forms
from System.Collections.Generic import *

# Get active revit document
docTo = revit.doc

# Select a document
docFrom = forms.select_open_docs(title='Select a document', button_name='Select', width=500, multiple=False)

# Make sure document is a valid choice
if not docFrom:
	forms.alert("No document chosen.", title= "Script cancelled")
	script.exit()
elif docFrom.IsFamilyDocument:
	forms.alert("Must choose a non-family document.", title= "Script cancelled")
	script.exit()

# get all views in bg document
views = DB.FilteredElementCollector(docFrom).OfCategory(DB.BuiltInCategory.OST_Views).WhereElementIsNotElementType().ToElements()

eles_unsorted = [v for v in views if v.IsTemplate]
eles_sorted   = sorted(eles_unsorted, key = lambda x: x.Name)

# create custom message class based on view object
class ElementToCopy(forms.TemplateListItem):
	@property
	def name(self):
		return self.item.Name

# Display view templates
options_ui = [ElementToCopy(v)for v in eles_sorted]
eles_copy = forms.SelectFromList.show(options_ui,title='Select templates',width=500,button_name='Copy',multiselect=True)

# Make sure templates are selected
if not eles_copy:
	forms.alert("No view templates chosen.", title= "Script cancelled")
	script.exit()

# Prepare for the copy
ids = [e.Id for e in eles_copy]
ids_copy = List[DB.ElementId](ids)
cpOpts = DB.CopyPasteOptions()
tfrm = DB.Transform

# Run a copy and paste
with revit.Transaction('Copy elements'):
	DB.ElementTransformUtils.CopyElements(docFrom, ids_copy, docTo, tfrm.Identity, cpOpts)
	forms.alert(str(len(ids)) + " elements copied.", title= "Script completed", warn_icon=False)