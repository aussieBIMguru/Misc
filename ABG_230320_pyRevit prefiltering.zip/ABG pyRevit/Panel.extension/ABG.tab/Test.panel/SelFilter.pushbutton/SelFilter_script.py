# import pyrevit libraries
from pyrevit import DB,revit
from pyrevit import forms,script

# get revit document, UI document
doc = revit.doc
uidoc = revit.uidoc

# import UI selection
from Autodesk.Revit.UI.Selection import *

# custom selection filter class
class CustomISelectionFilter(ISelectionFilter):
	def __init__(self, nom_category):
		self.nom_category = nom_category
	def AllowElement(self, e):
		if e.Category.Name in self.nom_category:
			return True
		else:
			return False

# list of category names
names_choose = ["Areas", "Ceilings", "Doors", "Floors", "Rooms", "Roofs", "Walls", "Windows"]

# selection UI for user to choose from
names_chosen = forms.SelectFromList.show(names_choose, title = "Choose categories", width = 300, height = 350, button_name = "Make a selection", multiselect = True)

# check if we have a selection
if not names_chosen:
	script.exit()
else:
	try:
		sel_filter = CustomISelectionFilter(names_chosen)
		sel_elements = uidoc.Selection.PickObjects(ObjectType.Element, sel_filter, "Select element(s)...")
	except:
		sel_elements = []

# import list class
import System
from System.Collections.Generic import List

# empty Element Id list
element_ids = List[DB.ElementId]()

# try to get the list of element Id's to selection
for s in sel_elements:
	try:
		elementId = s.ElementId
		element_ids.Add(elementId)
	except:
		pass

# select the elements
try:
	uidoc.Selection.SetElementIds(element_ids)
except:
	pass