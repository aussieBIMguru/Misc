# import pyrevit libraries
from pyrevit import revit,DB
from pyrevit import forms,script

# class to show template by name
class TemplateToPurge(forms.TemplateListItem):
	@property
	def name(self):
		return doc.GetElement(self.item).Name

# function to delete object
def deleteById(id):
	try:
		doc.Delete(id)
		return 1
	except:
		return 0

# get the document
doc = revit.doc

# get all views and vfts
views_all = DB.FilteredElementCollector(doc).OfClass(DB.View).WhereElementIsNotElementType().ToElements()
vfts_all  = DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType).WhereElementIsElementType().ToElements()

# get view templates, then used view templates by view and vfts
templates_all, templates_unused, templates_used = [],[],[]

# get view template Ids by view
for v in views_all:
	if v.IsTemplate:
		templates_all.append(v.Id)
	else:
		vtId = v.ViewTemplateId
		if vtId not in templates_used:
			templates_used.append(vtId)

# get view template Ids by view family type (vft)
for vft in vfts_all:
	vtId = vft.DefaultTemplateId
	if vtId not in templates_used:
		templates_used.append(vtId)

# get unused view templates
for vt in templates_all:
	if vt not in templates_used:
		templates_unused.append(vt)

# check we have templates to purge
if len(templates_unused) == 0:
	forms.alert("No templates to purge", title="Script cancelled")
	script.exit()

# UI to select templates to purge
return_options = \
	forms.SelectFromList.show(
	[TemplateToPurge(vt) for vt in templates_unused],
	title = "Select templates to purge",
	width = 500,
	button_name = "Purge",
	multiselect = True)

# see if no templates chosen
if not return_options:
	script.exit()
else:
	with revit.Transaction("Purge Templates"):
		count_deleted = 0
		for vt in return_options:
			count_deleted += deleteById(vt)

# outcome message for user
count_total = len(return_options)
count_failed = count_total - count_deleted

if count_failed == 0:
	msg = str(count_total) + " view templates deleted."
elif count_deleted == 0:
	msg = "No templates deleted successfully."
else:
	msg = str(count_deleted) + " view templates deleted. " + str(count_failed) + " view templates not deleted succesfully."

# final message to user
forms.alert(msg, title="Script completed", warn_icon=False)