# import pyrevit libraries
from pyrevit import forms,revit,DB,script
from System.Collections.Generic import List

# check version, cancel if pre-22
app = __revit__.Application
ver = int(app.VersionNumber)

if ver < 2022:
	forms.alert("Export PDF only available in Revit 2022+.", title= "Script cancelled")
	script.exit()

# Get directory to print to
dirPath = forms.pick_folder(title="Print to folder...")

if not dirPath:
	script.exit()

# get document
doc = revit.doc

# ask user for sheets
sheets = forms.select_sheets(title='Select Sheets', include_placeholder = False, use_selection = True)

if not sheets:
	script.exit()

# clean string and make document name
def legalize(str):
	reps = ['/','?','<','>','\\',':','*','|','"','^']
	newStr = ""
	for char in str:
		if char in reps:
			pass
		else:
			newStr += char
	return newStr

def makePdfName(s):
	# Get revision number
	try:
		curRev = s.GetCurrentRevision()
		if curRev == "":
			curNum = "-"
		else:
			curNum = s.GetRevisionNumberOnSheet(curRev)
	except:
		curNum = "-"
	# Get name and number
	nameUnclean = s.SheetNumber + "[" + curNum + "] -" + s.Name
	return legalize(nameUnclean)

# make pdf options
opts = DB.PDFExportOptions()
# settings as default
opts.HideCropBoundaries = True
opts.HideScopeBoxes = True
opts.HideReferencePlane = True
opts.HideUnreferencedViewTags = True
opts.MaskCoincidentLines = False
opts.PaperFormat = DB.ExportPaperFormat.Default

# export the sheets
with forms.ProgressBar(step=1, title='Exporting sheets... ' + '{value} of {max_value}', cancellable=True) as pb:
	# open the directory
	import os
	try:
		os.startfile(dirPath)
	except:
		pass
	# set progress bar values
	pbTotal = len(sheets)
	pbCount = 1
	for sht in sheets:
		if pb.cancelled:
			break
		else:
			opts.FileName = makePdfName(sht)
			# Prepare an Id list
			sheetId = List[DB.ElementId]()
			sheetId.Add(sht.Id)
			# Export the sheet to PDF
			doc.Export(dirPath, sheetId, opts)
		# Update progress bar
		pb.update_progress(pbCount, pbTotal)
		pbCount += 1

# Final message
if pb.cancelled:
	forms.alert("Export cancelled.", title= "Script cancelled")
else:
	forms.alert("Export complete.", title= "Script completed", warn_icon=False)