# import libraries
from pyrevit import script, forms
from datetime import datetime
import math

# get the time
time = datetime.now()
dt_f2 = time.strftime("%H-%M-%S")

# try to get data
try:
	dt_f1 = script.load_data("Sync start", this_project = True)
except:
	script.exit()

# break down the data
before = dt_f1.split("-")
after  = dt_f2.split("-")

# function to check seconds in time
def getSeconds(lst):
	h = int(lst[0]) * 60 * 60
	m = int(lst[1]) * 60
	s = int(lst[2])
	return h + m + s

# function to string
def timeToString(s):
	unpadded = str(s).split(".")[0]
	return unpadded.rjust(2,"0")

# try to report the time difference
try:
	elapsed = getSeconds(after) - getSeconds(before)
	mins = math.floor(elapsed/60)
	secs = elapsed % 60
	
	# form a message to the user
	msg = timeToString(mins) + "mins " + timeToString(secs) + "secs"
	
	# send this to windows
	forms.toaster.send_toast(msg, title = "Sync completed", appid=None, icon=None, click=None, actions=None)
except:
	pass