# Illegal character list
char_illegal = ["\\", ":", "{", "}", "[", "]", "|", ";", "<", ">", "?", "`", "~"]

# Check string legality for Revit
def isLegalRevit(str):
	check = True
	for c in str:
		if c in char_illegal:
			check = False
			break
	return check

# Make a string Revit legality
def makeLegalRevit(str, rep = ""):
	newStr = ""
	for c in str:
		if c in char_illegal:
			newStr += rep
		else:
			newStr += c
	return newStr