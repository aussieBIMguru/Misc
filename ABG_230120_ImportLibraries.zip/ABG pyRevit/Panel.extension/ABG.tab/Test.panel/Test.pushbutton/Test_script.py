# Import utilities
from util_strings import *

strlist = ["test1","test2","test["]

for s in strlist:
	legal = makeLegalRevit(s)
	print(legal)